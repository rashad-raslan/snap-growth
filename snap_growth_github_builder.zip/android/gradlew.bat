@echo off
set APP_HOME=%~dp0
set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar
if not exist "%CLASSPATH%" (
  echo Missing android\gradle\wrapper\gradle-wrapper.jar.
  echo Open this as a Flutter project in an environment with Flutter SDK to regenerate wrapper files.
  exit /b 1
)
java -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
