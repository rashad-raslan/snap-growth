import 'dart:math';

class Ideas {
  static final Random _random = Random();

  static const Map<String, List<String>> _ar = {
    'uni': [
      'شارك لقطة قصيرة من يومك الدراسي مع سؤال بسيط للمتابعين.',
      'اعمل سلسلة نصائح مذاكرة في ثلاث لقطات.',
      'شارك هدفك الدراسي لهذا الأسبوع واطلب من الناس مشاركة أهدافهم.',
    ],
    'personal': [
      'شارك موقفًا لطيفًا حصل لك اليوم بدون كشف خصوصية أي شخص.',
      'عرّف المتابعين على هواية تحبها في لقطة قصيرة.',
      'احكِ قصة صغيرة تعلّمت منها شيئًا مفيدًا.',
    ],
    'daily': [
      'صوّر لحظة بسيطة من يومك بإضاءة جيدة.',
      'استخدم تصويتًا أو سؤالًا لبدء محادثة مع المتابعين.',
      'شارك أفضل شيء حصل لك اليوم في لقطة واحدة.',
    ],
    'bts': [
      'اعرض كواليس تجهيز شيء تعمل عليه.',
      'شارك لقطة قبل وبعد مع شرح قصير.',
      'اعرض خطوة واحدة من طريقة عملك لشيء تحبه.',
    ],
    'caption': [
      'يوم جديد، فرصة جديدة ✨',
      'التفاصيل الصغيرة تصنع فرقًا كبيرًا.',
      'خلّي يومك بسيطًا وحلوًا.',
    ],
    'question': [
      'إيه أحسن حاجة حصلت لك النهارده؟',
      'تفضّل يوم هادي ولا يوم مليان مغامرات؟',
      'رشّح لي أغنية أسمعها النهارده.',
    ],
  };

  static const Map<String, List<String>> _en = {
    'uni': [
      'Share a short study-day moment and ask your audience a simple question.',
      'Make a three-snap series of useful study tips.',
      'Share one goal for this week and invite others to share theirs.',
    ],
    'personal': [
      'Share a small positive moment without exposing anyone’s privacy.',
      'Introduce your audience to a hobby you enjoy.',
      'Tell a short story about something useful you learned.',
    ],
    'daily': [
      'Capture a simple moment from your day in good lighting.',
      'Use a poll or question to start a conversation.',
      'Share the best part of your day in one snap.',
    ],
    'bts': [
      'Show a behind-the-scenes moment from something you are making.',
      'Share a before-and-after with a short explanation.',
      'Show one step of how you do something you enjoy.',
    ],
    'caption': [
      'New day, new opportunity ✨',
      'Small details make a big difference.',
      'Keep your day simple and good.',
    ],
    'question': [
      'What was the best part of your day?',
      'Do you prefer a quiet day or an adventurous one?',
      'Recommend a song for me today.',
    ],
  };

  static String one(String category, bool ar) {
    final map = ar ? _ar : _en;
    final items = map[category] ?? map['daily']!;
    return items[_random.nextInt(items.length)];
  }

  static List<String> combo(String category, bool ar) {
    final map = ar ? _ar : _en;
    final items = List<String>.from(map[category] ?? map['daily']!);
    items.shuffle(_random);
    return items.take(min(3, items.length)).toList();
  }

  static List<String> weeklyPlan(bool ar) {
    final cats = ['daily', 'question', 'bts', 'personal', 'caption', 'uni', 'daily'];
    return List.generate(7, (i) => '${i + 1}. ${one(cats[i], ar)}');
  }
}
