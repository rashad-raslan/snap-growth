import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import 'app_state.dart';

const kInk = Color(0xFF0F1419);
const kPanel = Color(0xFF182028);
const kMint = Color(0xFF3DDBC0);
const kCoral = Color(0xFFFF7A6B);
const kMuted = Color(0xFF93A1AE);

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kMint,
    brightness: Brightness.dark,
  ).copyWith(primary: kMint, onPrimary: kInk, secondary: kCoral, surface: kInk);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: kInk,
    appBarTheme: const AppBarTheme(backgroundColor: kInk, centerTitle: false),
    navigationBarTheme: const NavigationBarThemeData(backgroundColor: kPanel),
    textTheme: ThemeData.dark().textTheme.apply(fontSizeFactor: 1.05),
  );
}

class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.color});
  final Widget child;
  final Color? color;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color ?? kPanel,
          borderRadius: BorderRadius.circular(20),
        ),
        child: child,
      );
}

class Note extends StatelessWidget {
  const Note(this.text, {super.key, this.warn = false});
  final String text;
  final bool warn;

  @override
  Widget build(BuildContext context) => Panel(
        color: warn ? const Color(0xFF2B2320) : kPanel,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(warn ? Icons.info_outline : Icons.lightbulb_outline,
                color: warn ? kCoral : kMint),
            const SizedBox(width: 12),
            Expanded(child: Text(text, style: const TextStyle(height: 1.5))),
          ],
        ),
      );
}

void toast(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

Future<void> openUrl(BuildContext c, AppState s, String url) async {
  bool ok = false;
  try {
    final uri = Uri.tryParse(url);
    if (uri != null && (uri.scheme == 'https' || uri.scheme == 'http')) {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  } catch (_) {}
  if (!ok && c.mounted) {
    toast(c, s.t(
      'تعذر فتح الرابط. تأكد من وجود تطبيق سنابشات أو متصفح.',
      'Could not open the link. Make sure Snapchat or a browser is installed.',
    ));
  }
}

Future<void> copyText(BuildContext c, AppState s, String text) async {
  await Clipboard.setData(ClipboardData(text: text));
  if (c.mounted) toast(c, s.t('تم النسخ', 'Copied'));
}

Future<void> shareText(BuildContext c, AppState s, String text) async {
  try {
    await Share.share(text);
  } catch (_) {
    if (c.mounted) {
      toast(c, s.t('تعذرت المشاركة على هذا الجهاز',
          'Sharing is unavailable on this device'));
    }
  }
}

Future<String?> askText(
  BuildContext c,
  AppState s,
  String title, {
  String initial = '',
  bool number = false,
  int lines = 1,
}) {
  return showDialog<String>(
    context: c,
    builder: (_) => _TextDialog(
      s: s,
      title: title,
      initial: initial,
      number: number,
      lines: lines,
    ),
  );
}

class _TextDialog extends StatefulWidget {
  const _TextDialog({
    required this.s,
    required this.title,
    required this.initial,
    required this.number,
    required this.lines,
  });

  final AppState s;
  final String title;
  final String initial;
  final bool number;
  final int lines;

  @override
  State<_TextDialog> createState() => _TextDialogState();
}

class _TextDialogState extends State<_TextDialog> {
  late final TextEditingController ctl =
      TextEditingController(text: widget.initial);

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.title),
        content: TextField(
          controller: ctl,
          autofocus: true,
          maxLines: widget.lines,
          keyboardType:
              widget.number ? TextInputType.number : TextInputType.multiline,
          inputFormatters: widget.number
              ? [FilteringTextInputFormatter.digitsOnly]
              : null,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(widget.s.t('إلغاء', 'Cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, ctl.text.trim()),
            child: Text(widget.s.t('حفظ', 'Save')),
          ),
        ],
      );
}

Future<void> recordFollowers(BuildContext c, AppState s) async {
  final value = await askText(
    c,
    s,
    s.t('عدد المتابعين الحالي (تدخله بنفسك)',
        'Current followers (entered by you)'),
    number: true,
  );
  if (value == null || !c.mounted) return;
  final n = int.tryParse(value);
  if (n == null || n < 0) {
    toast(c, s.t('أدخل رقمًا صحيحًا', 'Enter a valid number'));
    return;
  }
  await s.addMeasurement(n);
  if (c.mounted) toast(c, s.t('تم تسجيل القياس', 'Measurement recorded'));
}

String fmtNum(int n) {
  final digits = n.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write(',');
    buffer.write(digits[i]);
  }
  return (n < 0 ? '-' : '') + buffer.toString();
}

String signed(int? n) {
  if (n == null) return '—';
  return n > 0 ? '+${fmtNum(n)}' : fmtNum(n);
}
