import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'app_state.dart';
import 'widgets.dart';
import 'screens/dashboard.dart';
import 'screens/promotion.dart';
import 'screens/ideas_screen.dart';
import 'screens/community.dart';
import 'screens/stats.dart';
import 'screens/settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.load();
  runApp(SnapGrowthApp(s: state));
}

class SnapGrowthApp extends StatelessWidget {
  const SnapGrowthApp({super.key, required this.s});
  final AppState s;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, child) => MaterialApp(
          title: 'Snap Growth',
          debugShowCheckedModeBanner: false,
          theme: buildTheme(),
          locale: Locale(s.lang),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: Home(s: s),
        ),
      );
}

class Home extends StatefulWidget {
  const Home({super.key, required this.s});
  final AppState s;

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = 0;

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final titles = [
      s.t('الرئيسية', 'Dashboard'),
      s.t('الترويج', 'Promotion'),
      s.t('أفكار المحتوى', 'Content ideas'),
      s.t('المجتمع', 'Community'),
      s.t('الإحصائيات', 'Statistics'),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[i],
            style: const TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            tooltip: s.t('الإعدادات', 'Settings'),
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => SettingsScreen(s: s)),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: i,
          children: [
            DashboardScreen(s: s),
            PromotionScreen(s: s),
            IdeasScreen(s: s),
            CommunityScreen(s: s),
            StatsScreen(s: s),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (value) => setState(() => i = value),
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.space_dashboard_outlined),
              label: titles[0]),
          NavigationDestination(
              icon: const Icon(Icons.campaign_outlined), label: titles[1]),
          NavigationDestination(
              icon: const Icon(Icons.auto_awesome_outlined),
              label: titles[2]),
          NavigationDestination(
              icon: const Icon(Icons.groups_outlined), label: titles[3]),
          NavigationDestination(
              icon: const Icon(Icons.show_chart), label: titles[4]),
        ],
      ),
    );
  }
}
