import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets.dart';

class CommunityScreen extends StatelessWidget {
  const CommunityScreen({super.key, required this.s});
  final AppState s;

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(s.t('المجتمع والتفاعل', 'Community & engagement'),
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Note(s.t(
            'هذه النسخة لا تحتوي على خادم مجتمع متصل. يمكنك تسجيل أفكار التعاون يدويًا على جهازك.',
            'This version has no connected community server. You can save collaboration notes locally on your device.',
          ), warn: true),
          FilledButton.icon(
            onPressed: () async {
              final report = await askText(
                  context, s, s.t('ملاحظة أو فكرة تعاون', 'Note or collaboration idea'),
                  lines: 3);
              if (report == null || report.trim().isEmpty) return;
              await s.addReport(report);
            },
            icon: const Icon(Icons.add),
            label: Text(s.t('إضافة ملاحظة', 'Add note')),
          ),
          const SizedBox(height: 12),
          if (s.reports.isEmpty)
            Note(s.t('لا توجد ملاحظات محفوظة.', 'No saved notes.'))
          else
            ...s.reports.asMap().entries.map((entry) => Panel(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: Text(entry.value)),
                      IconButton(
                        tooltip: s.t('حذف', 'Delete'),
                        onPressed: () => s.removeReport(entry.key),
                        icon: const Icon(Icons.delete_outline),
                      ),
                    ],
                  ),
                )),
        ],
      );
}
