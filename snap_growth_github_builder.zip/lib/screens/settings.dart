import 'package:flutter/material.dart';
import '../app_state.dart';
import '../logic.dart';
import '../widgets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.s});
  final AppState s;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController username =
      TextEditingController(text: widget.s.username);
  late final TextEditingController url =
      TextEditingController(text: widget.s.profileUrl);
  late final TextEditingController category =
      TextEditingController(text: widget.s.category);
  late final TextEditingController goal =
      TextEditingController(text: widget.s.goal.toString());

  AppState get s => widget.s;

  @override
  void dispose() {
    username.dispose();
    url.dispose();
    category.dispose();
    goal.dispose();
    super.dispose();
  }

  Future<void> save() async {
    final user = username.text.trim();
    final profile = url.text.trim();
    final target = int.tryParse(goal.text.trim());
    if (!Progress.validUsername(user)) {
      toast(context, s.t('اسم المستخدم غير صحيح (3 إلى 15 حرفًا).',
          'Invalid username (3 to 15 characters).'));
      return;
    }
    if (!Progress.validProfileUrl(profile)) {
      toast(context, s.t(
          'رابط سناب يجب أن يكون مثل https://www.snapchat.com/add/username',
          'Use a Snapchat profile link like https://www.snapchat.com/add/username'));
      return;
    }
    if (target == null || target < 1) {
      toast(context, s.t('أدخل هدفًا أكبر من صفر.', 'Enter a goal above zero.'));
      return;
    }
    await s.setProfile(
      username: user,
      profileUrl: profile,
      category: category.text.trim().isEmpty
          ? s.t('شخصي', 'Personal')
          : category.text.trim(),
      goal: target,
    );
    if (mounted) {
      toast(context, s.t('تم حفظ الإعدادات', 'Settings saved'));
      Navigator.pop(context);
    }
  }

  Future<void> reset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(s.t('إعادة ضبط التطبيق؟', 'Reset the app?')),
        content: Text(s.t('سيتم حذف القياسات والخطط والملاحظات المحفوظة.',
            'Saved measurements, plans, and notes will be deleted.')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(s.t('إلغاء', 'Cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(s.t('إعادة الضبط', 'Reset'))),
        ],
      ),
    );
    if (confirmed != true) return;
    await s.wipe();
    if (!mounted) return;
    username.text = s.username;
    url.text = s.profileUrl;
    category.text = s.category;
    goal.text = s.goal.toString();
    toast(context, s.t('تمت إعادة الضبط', 'App reset'));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(s.t('الإعدادات', 'Settings'))),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: username,
                    decoration: InputDecoration(
                      labelText: s.t('اسم المستخدم', 'Username'),
                      prefixText: '@',
                    ),
                    textInputAction: TextInputAction.next,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: url,
                    decoration: InputDecoration(
                        labelText: s.t('رابط ملف سنابشات', 'Snapchat profile URL')),
                    keyboardType: TextInputType.url,
                    textInputAction: TextInputAction.next,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: category,
                    decoration: InputDecoration(
                        labelText: s.t('نوع المحتوى', 'Content category')),
                    textInputAction: TextInputAction.next,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: goal,
                    decoration: InputDecoration(
                        labelText: s.t('هدف المتابعين', 'Follower goal')),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: save,
                      icon: const Icon(Icons.save_outlined),
                      label: Text(s.t('حفظ التغييرات', 'Save changes')),
                    ),
                  ),
                ],
              ),
            ),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.t('لغة التطبيق', 'App language'),
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'ar', label: Text('العربية')),
                      ButtonSegment(value: 'en', label: Text('English')),
                    ],
                    selected: {s.lang},
                    onSelectionChanged: (values) => s.setLang(values.first),
                  ),
                ],
              ),
            ),
            OutlinedButton.icon(
              onPressed: reset,
              icon: const Icon(Icons.delete_forever_outlined),
              label: Text(s.t('إعادة ضبط وحذف البيانات', 'Reset and delete data')),
              style: OutlinedButton.styleFrom(foregroundColor: kCoral),
            ),
            const SizedBox(height: 12),
            Note(s.t(
              'التطبيق لا يطلب كلمة مرور سنابشات ولا يضيف متابعين تلقائيًا. الإحصائيات تسجلها بنفسك.',
              'The app never asks for your Snapchat password or adds followers automatically. You enter statistics yourself.',
            ), warn: true),
          ],
        ),
      );
}
