import 'package:flutter/material.dart';
import '../app_state.dart';
import '../ideas.dart';
import '../widgets.dart';

class IdeasScreen extends StatefulWidget {
  const IdeasScreen({super.key, required this.s});
  final AppState s;

  @override
  State<IdeasScreen> createState() => _IdeasScreenState();
}

class _IdeasScreenState extends State<IdeasScreen> {
  String category = 'daily';

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final ar = s.isArabic;
    final options = <String, String>{
      'daily': s.t('يومي', 'Daily'),
      'question': s.t('أسئلة', 'Questions'),
      'bts': s.t('كواليس', 'Behind the scenes'),
      'personal': s.t('شخصي', 'Personal'),
      'uni': s.t('دراسة', 'Study'),
      'caption': s.t('عبارات', 'Captions'),
    };
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(s.t('أفكار جاهزة لحالاتك', 'Ready ideas for your stories'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: category,
          decoration: InputDecoration(
              labelText: s.t('نوع الفكرة', 'Idea category'),
              border: const OutlineInputBorder()),
          items: options.entries
              .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
              .toList(),
          onChanged: (v) => setState(() => category = v ?? 'daily'),
        ),
        const SizedBox(height: 14),
        ...Ideas.combo(category, ar).map((idea) => Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(idea, style: const TextStyle(fontSize: 16, height: 1.5)),
                  const SizedBox(height: 8),
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: Wrap(spacing: 8, children: [
                      IconButton(
                        tooltip: s.t('نسخ', 'Copy'),
                        onPressed: () => copyText(context, s, idea),
                        icon: const Icon(Icons.copy),
                      ),
                      IconButton(
                        tooltip: s.t('مشاركة', 'Share'),
                        onPressed: () => shareText(context, s, idea),
                        icon: const Icon(Icons.share),
                      ),
                    ]),
                  ),
                ],
              ),
            )),
        FilledButton.icon(
          onPressed: () => setState(() {}),
          icon: const Icon(Icons.refresh),
          label: Text(s.t('أفكار جديدة', 'New ideas')),
        ),
        const SizedBox(height: 18),
        Text(s.t('خطة أسبوعية', 'Weekly plan'),
            style: Theme.of(context).textTheme.titleMedium),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final line in Ideas.weeklyPlan(ar))
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(line, style: const TextStyle(height: 1.4)),
                ),
              FilledButton.tonalIcon(
                onPressed: () => shareText(
                    context, s, Ideas.weeklyPlan(ar).join('\n')),
                icon: const Icon(Icons.share),
                label: Text(s.t('شارك الخطة', 'Share plan')),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
