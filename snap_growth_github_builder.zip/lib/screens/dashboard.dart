import 'package:flutter/material.dart';

import '../app_state.dart';
import '../logic.dart';
import '../widgets.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.s});
  final AppState s;

  @override
  Widget build(BuildContext context) {
    final current = s.current;
    final history = s.history;
    final fraction = Progress.fraction(current, s.goal);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('@${s.username}',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        Text(s.category, style: const TextStyle(color: kMuted)),
        const SizedBox(height: 14),
        Panel(
          child: current == null
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.t('لا توجد قياسات بعد', 'No measurements yet'),
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text(s.t(
                        'افتح سنابشات، انظر عدد متابعيك، ثم سجّله هنا ليبدأ التتبع.',
                        'Open Snapchat, check your follower count, then record it here to start tracking.')),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: () => recordFollowers(context, s),
                      icon: const Icon(Icons.edit_note),
                      label: Text(s.t('سجّل أول قياس', 'Record first measurement')),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(fmtNum(current),
                              style: const TextStyle(
                                  fontSize: 44, fontWeight: FontWeight.w800)),
                        ),
                        const SizedBox(width: 10),
                        Chip(
                          label: Text(s.t('مُدخل يدويًا', 'Entered manually')),
                          visualDensity: VisualDensity.compact,
                        ),
                      ],
                    ),
                    Text(
                      s.t('آخر تحديث: ${fmtDate(history.last.at)}',
                          'Last updated: ${fmtDate(history.last.at)}'),
                      style: const TextStyle(color: kMuted),
                    ),
                    const SizedBox(height: 14),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: fraction,
                        minHeight: 12,
                        color: kMint,
                        backgroundColor: kInk,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(s.t(
                        '${(fraction * 100).toStringAsFixed(2)}٪ من الهدف ${fmtNum(s.goal)}',
                        '${(fraction * 100).toStringAsFixed(2)}% of the ${fmtNum(s.goal)} goal')),
                  ],
                ),
        ),
        if (current != null)
          Row(
            children: [
              _Delta(s.t('آخر قياس', 'Last entry'), Progress.deltaLast(history)),
              _Delta(s.t('٢٤ ساعة', '24 hours'),
                  Progress.deltaOver(history, const Duration(days: 1))),
              _Delta(s.t('٧ أيام', '7 days'),
                  Progress.deltaOver(history, const Duration(days: 7))),
            ],
          ),
        const SizedBox(height: 4),
        FilledButton.icon(
          style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54)),
          onPressed: () => openUrl(context, s, s.profileUrl),
          icon: const Icon(Icons.open_in_new),
          label: Text(s.t('افتح ملفي في سنابشات', 'Open my Snapchat profile')),
        ),
        const SizedBox(height: 10),
        FilledButton.tonalIcon(
          style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54)),
          onPressed: () => shareText(
              context, s, s.render(s.isArabic ? s.msgAr : s.msgEn)),
          icon: const Icon(Icons.share),
          label: Text(s.t('شارك رابط ملفي', 'Share my profile link')),
        ),
        if (current != null) ...[
          const SizedBox(height: 10),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(54)),
            onPressed: () => recordFollowers(context, s),
            icon: const Icon(Icons.add),
            label: Text(s.t('سجّل عدد المتابعين الآن', 'Record followers now')),
          ),
        ],
        const SizedBox(height: 14),
        Note(
          s.t(
            'كل الأرقام هنا تدخلها أنت يدويًا. التطبيق لا يتصل بسنابشات ولا يجلب أي إحصائيات منه.',
            'Every number here is entered by you. The app does not connect to Snapchat or fetch any statistics.',
          ),
          warn: true,
        ),
      ],
    );
  }
}

class _Delta extends StatelessWidget {
  const _Delta(this.label, this.value);
  final String label;
  final int? value;

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          margin: const EdgeInsetsDirectional.only(end: 8, bottom: 14),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          decoration: BoxDecoration(
              color: kPanel, borderRadius: BorderRadius.circular(16)),
          child: Column(
            children: [
              Text(
                signed(value),
                textDirection: TextDirection.ltr,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: value == null
                      ? kMuted
                      : (value! >= 0 ? kMint : kCoral),
                ),
              ),
              const SizedBox(height: 4),
              Text(label,
                  style: const TextStyle(color: kMuted, fontSize: 12)),
            ],
          ),
        ),
      );
}
