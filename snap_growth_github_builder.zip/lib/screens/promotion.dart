import 'package:flutter/material.dart';
import '../app_state.dart';
import '../ideas.dart';
import '../logic.dart';
import '../widgets.dart';

class PromotionScreen extends StatefulWidget {
  const PromotionScreen({super.key, required this.s});
  final AppState s;

  @override
  State<PromotionScreen> createState() => _PromotionScreenState();
}

class _PromotionScreenState extends State<PromotionScreen> {
  AppState get s => widget.s;

  @override
  Widget build(BuildContext context) {
    final ar = s.isArabic;
    final message = ar ? s.msgAr : s.msgEn;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(s.t('شارك ملفك بطريقة سهلة', 'Share your profile easily'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        Panel(child: SelectableText(s.profileUrl)),
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              onPressed: () => copyText(context, s, s.profileUrl),
              icon: const Icon(Icons.copy),
              label: Text(s.t('نسخ الرابط', 'Copy link')),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: FilledButton.tonalIcon(
              onPressed: () => shareText(context, s, s.profileUrl),
              icon: const Icon(Icons.share),
              label: Text(s.t('مشاركة', 'Share')),
            ),
          ),
        ]),
        const SizedBox(height: 16),
        Text(s.t('رسالة جاهزة', 'Ready-to-share message'),
            style: Theme.of(context).textTheme.titleMedium),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SelectableText(s.render(message)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, children: [
                OutlinedButton.icon(
                  onPressed: () async {
                    final result = await askText(context, s,
                        s.t('تعديل الرسالة', 'Edit message'),
                        initial: message, lines: 4);
                    if (result == null) return;
                    await s.saveMessages(ar: ar ? result : null,
                        en: ar ? null : result);
                  },
                  icon: const Icon(Icons.edit),
                  label: Text(s.t('تعديل', 'Edit')),
                ),
                FilledButton.icon(
                  onPressed: () => shareText(context, s, s.render(message)),
                  icon: const Icon(Icons.share),
                  label: Text(s.t('مشاركة الرسالة', 'Share message')),
                ),
              ]),
            ],
          ),
        ),
        Text(s.t('أفكار سريعة للترويج', 'Quick promotion ideas'),
            style: Theme.of(context).textTheme.titleMedium),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final idea in Ideas.combo('daily', ar))
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.check_circle_outline, color: kMint),
                      const SizedBox(width: 8),
                      Expanded(child: Text(idea)),
                    ],
                  ),
                ),
            ],
          ),
        ),
        Text(s.t('تقويم المحتوى', 'Content calendar'),
            style: Theme.of(context).textTheme.titleMedium),
        FilledButton.icon(
          onPressed: () async {
            final title = await askText(context, s,
                s.t('عنوان المنشور أو الحالة', 'Post or story title'));
            if (title == null || title.trim().isEmpty || !context.mounted) return;
            final date = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime.now().subtract(const Duration(days: 365)),
              lastDate: DateTime.now().add(const Duration(days: 3650)),
            );
            if (date != null) await s.addCal(title, date);
          },
          icon: const Icon(Icons.add),
          label: Text(s.t('أضف خطة', 'Add plan')),
        ),
        const SizedBox(height: 12),
        if (s.calendar.isEmpty)
          Note(s.t('لا توجد خطط محفوظة حتى الآن.', 'No saved plans yet.'))
        else
          ...s.calendar.map((item) => Panel(
                child: Row(children: [
                  Checkbox(
                    value: item.done,
                    onChanged: (_) => s.toggleCal(item.id),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.title,
                            style: TextStyle(
                                decoration: item.done
                                    ? TextDecoration.lineThrough
                                    : null)),
                        Text(fmtDate(item.date),
                            style: const TextStyle(color: kMuted)),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => s.removeCal(item.id),
                    icon: const Icon(Icons.delete_outline),
                  ),
                ]),
              )),
      ],
    );
  }
}
