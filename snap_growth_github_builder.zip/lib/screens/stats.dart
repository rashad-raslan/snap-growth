import 'package:flutter/material.dart';
import '../app_state.dart';
import '../logic.dart';
import '../widgets.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key, required this.s});
  final AppState s;

  @override
  Widget build(BuildContext context) {
    final history = s.history;
    final current = s.current;
    final rate = Progress.perDay(history);
    final days = Progress.daysToGoal(current, s.goal, history);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(s.t('إحصائيات النمو', 'Growth statistics'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        Row(children: [
          _StatCard(
              title: s.t('القياسات', 'Entries'),
              value: fmtNum(history.length),
              icon: Icons.history),
          const SizedBox(width: 10),
          _StatCard(
              title: s.t('متوسط يومي', 'Daily average'),
              value: rate == null ? '—' : rate.toStringAsFixed(1),
              icon: Icons.trending_up),
        ]),
        const SizedBox(height: 10),
        Panel(
          child: Row(children: [
            const Icon(Icons.flag_outlined, color: kMint, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.t('الوقت التقديري للوصول للهدف',
                        'Estimated time to goal')),
                    const SizedBox(height: 5),
                    Text(
                      current == null
                          ? s.t('سجّل أول قياس', 'Record your first entry')
                          : current >= s.goal
                              ? s.t('وصلت للهدف 🎉', 'Goal reached 🎉')
                              : days == null
                                  ? s.t('يلزم قياسان على الأقل ومعدل نمو موجب',
                                      'Need at least two entries and a positive growth rate')
                                  : s.t('$days يوم تقريبًا', 'About $days days'),
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ]),
            ),
          ]),
        ),
        if (history.length >= 2) ...[
          Text(s.t('سجل المتابعين', 'Follower history'),
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Panel(
            child: SizedBox(
              height: 180,
              width: double.infinity,
              child: CustomPaint(painter: _ChartPainter(history)),
            ),
          ),
        ],
        Text(s.t('القياسات المسجلة', 'Recorded measurements'),
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (history.isEmpty)
          Note(s.t('لا توجد قياسات. أضف عدد المتابعين من الرئيسية.',
              'No entries yet. Add your follower count from the dashboard.'))
        else
          ...history.asMap().entries.toList().reversed.map((entry) => Panel(
                child: Row(children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(fmtNum(entry.value.followers),
                            style: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold)),
                        Text(fmtDate(entry.value.at),
                            style: const TextStyle(color: kMuted)),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: s.t('حذف القياس', 'Delete entry'),
                    onPressed: () async {
                      final yes = await showDialog<bool>(
                        context: context,
                        builder: (dialogContext) => AlertDialog(
                          title: Text(s.t('حذف القياس؟', 'Delete entry?')),
                          actions: [
                            TextButton(
                              onPressed: () =>
                                  Navigator.pop(dialogContext, false),
                              child: Text(s.t('إلغاء', 'Cancel')),
                            ),
                            FilledButton(
                              onPressed: () =>
                                  Navigator.pop(dialogContext, true),
                              child: Text(s.t('حذف', 'Delete')),
                            ),
                          ],
                        ),
                      );
                      if (yes == true) await s.removeMeasurement(entry.key);
                    },
                    icon: const Icon(Icons.delete_outline),
                  ),
                ]),
              )),
        if (history.isNotEmpty)
          OutlinedButton.icon(
            onPressed: () async {
              final yes = await showDialog<bool>(
                context: context,
                builder: (dialogContext) => AlertDialog(
                  title: Text(s.t('مسح كل القياسات؟', 'Clear all entries?')),
                  content: Text(s.t('لن يمكن التراجع عن هذا الإجراء.',
                      'This action cannot be undone.')),
                  actions: [
                    TextButton(
                        onPressed: () =>
                            Navigator.pop(dialogContext, false),
                        child: Text(s.t('إلغاء', 'Cancel'))),
                    FilledButton(
                        onPressed: () =>
                            Navigator.pop(dialogContext, true),
                        child: Text(s.t('مسح', 'Clear'))),
                  ],
                ),
              );
              if (yes == true) {
                for (var i = s.history.length - 1; i >= 0; i--) {
                  await s.removeMeasurement(i);
                }
              }
            },
            icon: const Icon(Icons.delete_sweep_outlined),
            label: Text(s.t('مسح كل القياسات', 'Clear all entries')),
          ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard(
      {required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Expanded(
        child: Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: kMint),
              const SizedBox(height: 10),
              Text(value,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w800)),
              Text(title, style: const TextStyle(color: kMuted)),
            ],
          ),
        ),
      );
}

class _ChartPainter extends CustomPainter {
  _ChartPainter(this.history);
  final List<Measurement> history;

  @override
  void paint(Canvas canvas, Size size) {
    if (history.length < 2 || size.width <= 0 || size.height <= 0) return;
    const inset = 8.0;
    final values = history.map((e) => e.followers.toDouble()).toList();
    final minValue = values.reduce((a, b) => a < b ? a : b);
    final maxValue = values.reduce((a, b) => a > b ? a : b);
    final range = maxValue - minValue;
    final paint = Paint()
      ..color = kMint
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = inset + (size.width - inset * 2) * i / (values.length - 1);
      final y = range == 0
          ? size.height / 2
          : size.height - inset -
              ((values[i] - minValue) / range) * (size.height - inset * 2);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _ChartPainter oldDelegate) =>
      oldDelegate.history != history;
}
