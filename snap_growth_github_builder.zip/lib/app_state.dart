import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'logic.dart';

class AppState extends ChangeNotifier {
  static const _defaultUsername = 'rashad_4aslan';
  static const _defaultUrl = 'https://www.snapchat.com/add/rashad_4aslan';

  String username = _defaultUsername;
  String profileUrl = _defaultUrl;
  String category = 'شخصي';
  int goal = 100000;
  String lang = 'ar';
  String msgAr = 'تابعني على سناب شات 👻\nرابط حسابي: {link}';
  String msgEn = 'Follow me on Snapchat 👻\nMy profile: {link}';

  List<Measurement> history = <Measurement>[];
  List<CalItem> calendar = <CalItem>[];
  List<String> reports = <String>[];

  final CommunityBackend backend = NoBackend();
  SharedPreferences? _prefs;

  bool get isArabic => lang == 'ar';
  int? get current => history.isEmpty ? null : history.last.followers;

  String t(String ar, String en) => isArabic ? ar : en;

  String render(String template) => template.replaceAll('{link}', profileUrl);

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final p = _prefs!;
    username = p.getString('username') ?? _defaultUsername;
    profileUrl = p.getString('profileUrl') ?? _defaultUrl;
    category = p.getString('category') ?? 'شخصي';
    goal = p.getInt('goal') ?? 100000;
    lang = p.getString('lang') ?? 'ar';
    msgAr = p.getString('msgAr') ?? msgAr;
    msgEn = p.getString('msgEn') ?? msgEn;
    history = _readList<Measurement>(
      p.getString('history'),
      (m) => Measurement.fromJson(m),
    )..sort((a, b) => a.at.compareTo(b.at));
    calendar = _readList<CalItem>(
      p.getString('calendar'),
      (m) => CalItem.fromJson(m),
    )..sort((a, b) => a.date.compareTo(b.date));
    reports = _readList<String>(
      p.getString('reports'),
      (m) => m['text']?.toString() ?? '',
    );
    notifyListeners();
  }

  List<T> _readList<T>(String? raw, T Function(Map<String, dynamic>) decode) {
    if (raw == null || raw.isEmpty) return <T>[];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return <T>[];
      return decoded
          .whereType<Map>()
          .map((e) => decode(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      return <T>[];
    }
  }

  Future<void> _save() async {
    final p = _prefs ??= await SharedPreferences.getInstance();
    await p.setString('username', username);
    await p.setString('profileUrl', profileUrl);
    await p.setString('category', category);
    await p.setInt('goal', goal);
    await p.setString('lang', lang);
    await p.setString('msgAr', msgAr);
    await p.setString('msgEn', msgEn);
    await p.setString('history', jsonEncode(history.map((e) => e.toJson()).toList()));
    await p.setString('calendar', jsonEncode(calendar.map((e) => e.toJson()).toList()));
    await p.setString('reports', jsonEncode(reports.map((e) => {'text': e}).toList()));
    notifyListeners();
  }

  Future<void> setLang(String value) async {
    lang = value == 'en' ? 'en' : 'ar';
    await _save();
  }

  Future<void> setProfile({
    required String username,
    required String profileUrl,
    required String category,
    required int goal,
  }) async {
    this.username = username.trim();
    this.profileUrl = profileUrl.trim();
    this.category = category.trim();
    this.goal = goal < 1 ? 1 : goal;
    await _save();
  }

  Future<void> addMeasurement(int followers) async {
    if (followers < 0) return;
    history.add(Measurement(at: DateTime.now(), followers: followers));
    history.sort((a, b) => a.at.compareTo(b.at));
    await _save();
  }

  Future<void> removeMeasurement(int index) async {
    if (index < 0 || index >= history.length) return;
    history.removeAt(index);
    await _save();
  }

  Future<void> saveMessages({String? ar, String? en}) async {
    if (ar != null) msgAr = ar;
    if (en != null) msgEn = en;
    await _save();
  }

  Future<void> addCal(String title, DateTime date) async {
    calendar.add(CalItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title.trim(),
      date: date,
    ));
    calendar.sort((a, b) => a.date.compareTo(b.date));
    await _save();
  }

  Future<void> toggleCal(String id) async {
    calendar = calendar
        .map((item) => item.id == id ? item.copyWith(done: !item.done) : item)
        .toList();
    await _save();
  }

  Future<void> removeCal(String id) async {
    calendar.removeWhere((item) => item.id == id);
    await _save();
  }

  Future<void> addReport(String report) async {
    reports.insert(0, '${fmtDate(DateTime.now())} — ${report.trim()}');
    await _save();
  }

  Future<void> removeReport(int index) async {
    if (index < 0 || index >= reports.length) return;
    reports.removeAt(index);
    await _save();
  }

  Future<void> wipe() async {
    final p = _prefs ??= await SharedPreferences.getInstance();
    await p.clear();
    username = _defaultUsername;
    profileUrl = _defaultUrl;
    category = 'شخصي';
    goal = 100000;
    lang = 'ar';
    msgAr = 'تابعني على سناب شات 👻\nرابط حسابي: {link}';
    msgEn = 'Follow me on Snapchat 👻\nMy profile: {link}';
    history.clear();
    calendar.clear();
    reports.clear();
    await _save();
  }
}
