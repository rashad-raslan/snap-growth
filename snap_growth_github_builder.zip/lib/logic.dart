class Measurement {
  const Measurement({required this.at, required this.followers});

  final DateTime at;
  final int followers;

  Map<String, dynamic> toJson() => {
        'at': at.toIso8601String(),
        'followers': followers,
      };

  factory Measurement.fromJson(Map<String, dynamic> json) {
    return Measurement(
      at: DateTime.tryParse(json['at']?.toString() ?? '') ?? DateTime.now(),
      followers: _safeInt(json['followers']),
    );
  }
}

class CalItem {
  const CalItem({
    required this.id,
    required this.title,
    required this.date,
    this.done = false,
  });

  final String id;
  final String title;
  final DateTime date;
  final bool done;

  CalItem copyWith({String? title, DateTime? date, bool? done}) => CalItem(
        id: id,
        title: title ?? this.title,
        date: date ?? this.date,
        done: done ?? this.done,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'date': date.toIso8601String(),
        'done': done,
      };

  factory CalItem.fromJson(Map<String, dynamic> json) => CalItem(
        id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: json['title']?.toString() ?? '',
        date: DateTime.tryParse(json['date']?.toString() ?? '') ?? DateTime.now(),
        done: json['done'] == true,
      );
}

int _safeInt(dynamic value) {
  if (value is int) return value < 0 ? 0 : value;
  return int.tryParse(value?.toString() ?? '') ?? 0;
}

class Progress {
  static double fraction(int? current, int goal) {
    if (current == null || goal <= 0) return 0;
    return (current / goal).clamp(0.0, 1.0).toDouble();
  }

  static int? deltaLast(List<Measurement> history) {
    if (history.length < 2) return null;
    return history.last.followers - history[history.length - 2].followers;
  }

  static int? deltaOver(List<Measurement> history, Duration duration) {
    if (history.length < 2) return null;
    final latest = history.last;
    final cutoff = latest.at.subtract(duration);
    Measurement? earlier;
    for (final item in history) {
      if (!item.at.isAfter(cutoff)) earlier = item;
    }
    if (earlier == null) return null;
    return latest.followers - earlier.followers;
  }

  static double? perDay(List<Measurement> history) {
    if (history.length < 2) return null;
    final first = history.first;
    final last = history.last;
    final days = last.at.difference(first.at).inMinutes / (60 * 24);
    if (days <= 0) return null;
    return (last.followers - first.followers) / days;
  }

  static int? daysToGoal(int? current, int goal, List<Measurement> history) {
    if (current == null || current >= goal) return 0;
    final rate = perDay(history);
    if (rate == null || rate <= 0) return null;
    return ((goal - current) / rate).ceil();
  }

  static bool validUsername(String username) =>
      RegExp(r'^[A-Za-z][A-Za-z0-9._-]{2,14}$').hasMatch(username.trim());

  static bool validProfileUrl(String value) {
    final uri = Uri.tryParse(value.trim());
    if (uri == null || uri.scheme != 'https') return false;
    if (uri.host != 'snapchat.com' && uri.host != 'www.snapchat.com') return false;
    final parts = uri.pathSegments;
    if (parts.length < 2 || parts.first != 'add') return false;
    return validUsername(parts[1]);
  }
}

abstract class CommunityBackend {
  bool get isConfigured;
}

class NoBackend implements CommunityBackend {
  @override
  bool get isConfigured => false;
}

String fmtDate(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
}
